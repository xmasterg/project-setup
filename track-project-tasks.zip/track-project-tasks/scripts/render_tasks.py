#!/usr/bin/env python3
import json
from datetime import datetime, timezone
from pathlib import Path

REQUIRED = {
    "id", "type", "title", "section", "status", "priority", "owner",
    "parent_id", "depends_on", "tags", "description", "acceptance", "notes",
    "reproduction", "expected", "actual", "created_at", "updated_at", "completed_at",
}
TYPES = {"feature", "task", "bug", "chore", "research"}
STATUSES = {"backlog", "ready", "in_progress", "blocked", "done"}
PRIORITIES = {"P0", "P1", "P2", "P3"}


def validate(tasks: list) -> None:
    ids = [task.get("id") for task in tasks]
    if len(ids) != len(set(ids)):
        raise SystemExit("Task IDs must be unique")
    known = set(ids)
    for index, task in enumerate(tasks):
        missing = REQUIRED - set(task)
        if missing:
            raise SystemExit(f"Task {index + 1} is missing: {', '.join(sorted(missing))}")
        if task["type"] not in TYPES or task["status"] not in STATUSES or task["priority"] not in PRIORITIES:
            raise SystemExit(f"Task {task['id']} has an invalid type, status, or priority")
        references = ([task["parent_id"]] if task["parent_id"] else []) + task["depends_on"]
        unknown = [item for item in references if item not in known]
        if unknown:
            raise SystemExit(f"Task {task['id']} references unknown IDs: {', '.join(unknown)}")


def main() -> None:
    agents = Path(__file__).resolve().parent
    data_path = agents / "tasks.json"
    template_path = agents / "task-board.template.html"
    output_path = agents / "task-board.html"
    data = json.loads(data_path.read_text(encoding="utf-8"))
    if not isinstance(data.get("tasks"), list):
        raise SystemExit(".agents/tasks.json must contain a tasks array")
    validate(data["tasks"])
    data["updated_at"] = datetime.now(timezone.utc).isoformat(timespec="seconds")
    data_path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    payload = json.dumps(data, ensure_ascii=False).replace("</", "<\\/")
    template = template_path.read_text(encoding="utf-8")
    if "__TASK_DATA__" not in template:
        raise SystemExit("Task board template is missing __TASK_DATA__")
    output_path.write_text(template.replace("__TASK_DATA__", payload), encoding="utf-8")
    print(f"Rendered {len(data['tasks'])} tasks to {output_path}")


if __name__ == "__main__":
    main()
