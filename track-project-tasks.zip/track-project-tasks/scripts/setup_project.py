#!/usr/bin/env python3
import argparse
import shutil
import subprocess
from pathlib import Path


def main() -> None:
    parser = argparse.ArgumentParser(description="Install the local task tracker in a project")
    parser.add_argument("--root", default=".")
    args = parser.parse_args()
    root = Path(args.root).resolve()
    if not root.is_dir():
        raise SystemExit(f"Project root does not exist: {root}")

    skill = Path(__file__).resolve().parent.parent
    agents = root / ".agents"
    agents.mkdir(exist_ok=True)
    copies = {
        skill / "assets" / "tasks.json": agents / "tasks.json",
        skill / "assets" / "task-board.template.html": agents / "task-board.template.html",
        skill / "scripts" / "render_tasks.py": agents / "render_tasks.py",
    }
    for source, target in copies.items():
        if not target.exists():
            shutil.copy2(source, target)

    agents_md = root / "AGENTS.md"
    block = (skill / "assets" / "AGENTS.block.md").read_text(encoding="utf-8").strip()
    existing = agents_md.read_text(encoding="utf-8") if agents_md.exists() else ""
    if "<!-- task-tracker:start -->" not in existing:
        separator = "\n\n" if existing.strip() else ""
        agents_md.write_text(existing.rstrip() + separator + block + "\n", encoding="utf-8")

    subprocess.run(["python3", str(agents / "render_tasks.py")], cwd=root, check=True)
    print(f"Task tracker ready: {agents / 'task-board.html'}")


if __name__ == "__main__":
    main()
