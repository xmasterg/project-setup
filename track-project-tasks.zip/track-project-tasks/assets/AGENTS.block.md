<!-- task-tracker:start -->
## Local task tracking

Use the `track-project-tasks` skill for project tasks, bugs, feature breakdowns, delegation, blockers, and handoffs. `.agents/tasks.json` is authoritative. Update it before material work and after status changes, then run `python3 .agents/render_tasks.py`. The generated `.agents/task-board.html` is read-only and must not be edited manually.
<!-- task-tracker:end -->
