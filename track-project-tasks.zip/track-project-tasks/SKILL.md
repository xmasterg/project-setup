---
name: track-project-tasks
description: Set up and maintain a project-local, file-based task tracker for AI-agent work. Use when Codex needs to install the tracker, record or update tasks and bugs, plan or break down a major feature, delegate work to sub-agents, mark work blocked or done, reconcile pending work, or regenerate the read-only Kanban/list board stored under a project's .agents directory.
---

# Track project tasks

Keep `.agents/tasks.json` authoritative. Treat `.agents/task-board.html` as generated output; never edit it manually.

## Install

From the target project root, resolve the absolute path of this `SKILL.md` and run:

```bash
python3 "$(dirname "<absolute path of this SKILL.md>")/scripts/setup_project.py" --root "$PWD"
```

The installer creates only missing files, appends a bounded instruction block to `AGENTS.md`, and renders the board. Preserve existing project content.

## Work protocol

1. Read `.agents/tasks.json` before planning or changing code.
2. Add or update the smallest useful records before starting material work.
3. Set the active task to `in_progress`. Keep at most one `in_progress` task per agent.
4. For a major feature, create one parent feature and child tasks that are independently verifiable. Do not split trivial work.
5. Before delegating, create the child task, set its `owner` to the sub-agent name, and set `status` to `in_progress`. Give the sub-agent the task ID. Sub-agents may update only their task and children they create.
6. If work cannot continue, set `status` to `blocked`, add `#blocked`, and state the concrete blocker in `notes`. Keep unresolved dependencies in `depends_on`.
7. Mark `done` only after the task's acceptance checks pass. Add `completed_at`; briefly record evidence in `notes`. A parent becomes `done` only when all required children are done.
8. Do not delete completed records during normal work. Reopen by changing status and adding a note.
9. After every task-file change, run `python3 .agents/render_tasks.py`.
10. Before handoff, reconcile stale `in_progress` items, regenerate the board, and report remaining `blocked`, `ready`, or `backlog` IDs.

## Record rules

Use IDs `TASK-####` and `BUG-####`, monotonically increasing within each prefix.

Required fields for every record:

- `id`, `type`, `title`, `section`, `status`, `priority`
- `owner`, `parent_id`, `depends_on`, `tags`
- `description`, `acceptance`, `notes`
- `created_at`, `updated_at`, `completed_at`

Allowed values:

- `type`: `feature`, `task`, `bug`, `chore`, `research`
- `status`: `backlog`, `ready`, `in_progress`, `blocked`, `done`
- `priority`: `P0`, `P1`, `P2`, `P3`

For bugs, also populate `reproduction`, `expected`, and `actual`. For non-bugs, keep them as empty strings.

Write titles as observable outcomes, not vague activity. Keep `description` short. Put verification statements in `acceptance`. Use ISO-8601 timestamps. Use `owner: "unassigned"` when nobody owns the item.

## Tags and flags

Use lowercase kebab-case tags. Ordinary labels have no prefix requirement beyond `#`, such as `#frontend` or `#api`. Reserve:

- `#blocked` — cannot proceed now
- `#needs-user` — requires a user decision or input
- `#needs-review` — implementation finished, verification/review pending
- `#risk` — meaningful technical or product risk
- `#quick-win` — small, self-contained task
- `#follow-up` — valid work intentionally deferred

Do not encode status or priority in extra tags.

## Safe editing

Preserve unknown top-level keys and record fields. Validate JSON before rendering. Never rewrite unrelated project files. The installer-owned `AGENTS.md` block is delimited by `<!-- task-tracker:start -->` and `<!-- task-tracker:end -->`.
